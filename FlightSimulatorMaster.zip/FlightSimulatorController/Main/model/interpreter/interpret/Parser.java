package model.interpreter.interpret;

public interface Parser {
    public void parse();
}
