package model.interpreter.interpret;
import java.util.ArrayList;

public interface Lexer<V> {
	public ArrayList<String[]> lexicalCheck();
}
