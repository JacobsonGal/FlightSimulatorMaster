package model.interpreter.expressions;

public class Number implements Expression{

	private double value;
	
	public Number(double value) {
		this.value=value;
	}
	
	public void setValue(double value){
		this.value=value;
	}

	@Override
	public double calculate() {
		return value;
	}
}
