package model.interpreter.expressions;

public interface Expression {
	public double calculate();
}
