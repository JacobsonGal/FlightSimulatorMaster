package model.interpreter.commands;

public interface Command {
	void executeCommand(String[] array);
}
